# Calcolatore Forni Ceramici — APK via GitHub Actions

Questo progetto contiene il calcolatore HTML v29 dentro un'app Android WebView, configurata per lavorare offline.

## Creare l'APK direttamente dal cellulare
1. Crea un repository GitHub vuoto (es. `calcolatore-forni-ceramici`).
2. Carica tutti i file e cartelle di questo progetto nella radice del repository.
3. Vai nella scheda **Actions**.
4. Apri **Build APK**.
5. Tocca **Run workflow**.
6. Al termine apri l'esecuzione completata e scarica l'artifact **Calcolatore-Forni-Ceramici-APK**.
7. Estrai l'artifact e installa `app-debug.apk` sul telefono.

Non serve Android Studio sul telefono. GitHub compila il progetto sui propri server.

## Note
- Il contenuto web è incluso in `app/src/main/assets/index.html`.
- Il caricamento avviene da `file:///android_asset/index.html`, evitando il problema appassets.androidplatform.net del builder precedente.
- La fotocamera/galleria è gestita dal WebView wrapper.
- L'APK è una build debug, adatta alla prova. Per una versione pubblicabile servirà una firma release.
